// Countdown Timer
const countdownDate = new Date("Dec 12, 2025 10:00:00").getTime();
const daysEl = document.getElementById("days");
const hoursEl = document.getElementById("hours");
const minutesEl = document.getElementById("minutes");
const secondsEl = document.getElementById("seconds");

setInterval(() => {
  const now = new Date().getTime();
  const distance = countdownDate - now;
  daysEl.innerText = Math.floor(distance / (1000*60*60*24));
  hoursEl.innerText = Math.floor((distance % (1000*60*60*24)) / (1000*60*60));
  minutesEl.innerText = Math.floor((distance % (1000*60*60)) / (1000*60));
  secondsEl.innerText = Math.floor((distance % (1000*60)) / 1000);
}, 1000);

// RSVP Form
const form = document.getElementById("rsvpForm");
const thankYou = document.getElementById("thankyou");
form.addEventListener("submit", e => {
  e.preventDefault();
  form.style.display = "none";
  thankYou.style.display = "block";
});

// Music Play/Pause
const music = document.getElementById("bgMusic");
const musicBtn = document.getElementById("musicBtn");
musicBtn.addEventListener("click", () => {
  if (music.paused) { music.play(); musicBtn.innerText = "Pause Musik"; }
  else { music.pause(); musicBtn.innerText = "Play Musik"; }
});

// Share Function
function shareWhatsApp() {
  const url = encodeURIComponent(window.location.href);
  window.open(`https://wa.me/?text=Undangan%20Pernikahan:%20${url}`, "_blank");
}
function copyLink() {
  navigator.clipboard.writeText(window.location.href);
  alert("Link undangan telah disalin!");
}

// AOS Animations
AOS.init({ duration: 1000 });